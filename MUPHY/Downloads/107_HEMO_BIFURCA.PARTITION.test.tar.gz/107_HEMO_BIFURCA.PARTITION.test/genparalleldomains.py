#!/usr/bin/env python 
from MagicUniverse import *

MagicBegins()

preprocess_parallel_mesh(4)


